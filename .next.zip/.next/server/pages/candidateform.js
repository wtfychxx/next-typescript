(() => {
var exports = {};
exports.id = 730;
exports.ids = [730,641];
exports.modules = {

/***/ 756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ candidateform),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(297);
;// CONCATENATED MODULE: external "moment"
const external_moment_namespaceObject = require("moment");
var external_moment_default = /*#__PURE__*/__webpack_require__.n(external_moment_namespaceObject);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
;// CONCATENATED MODULE: external "react-datepicker"
const external_react_datepicker_namespaceObject = require("react-datepicker");
var external_react_datepicker_default = /*#__PURE__*/__webpack_require__.n(external_react_datepicker_namespaceObject);
// EXTERNAL MODULE: ./node_modules/react-datepicker/dist/react-datepicker.css
var react_datepicker = __webpack_require__(994);
;// CONCATENATED MODULE: external "zustand"
const external_zustand_namespaceObject = require("zustand");
var external_zustand_default = /*#__PURE__*/__webpack_require__.n(external_zustand_namespaceObject);
;// CONCATENATED MODULE: ./lib/candidate.ts

const useStoreOption = external_zustand_default()(set => ({
  dataPositionApplied: [],
  setPositionApplied: data => set(() => ({
    dataPositionApplied: data
  }))
}));
;// CONCATENATED MODULE: ./lib/upload.ts
function uploadFile(file) {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', 'ml_default');
  const config = {
    method: 'POST',
    body: formData
  };
  return config;
}
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(282);
;// CONCATENATED MODULE: ./components/Candidate.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












const Candidate = () => {
  const {
    dataPositionApplied
  } = useStoreOption();
  const {
    0: signUpData,
    1: setSignUpData
  } = (0,external_react_.useState)({
    officialName: "",
    nickName: "",
    positionApplied: "",
    informationSource: "",
    birthCity: "",
    email: "",
    gender: "",
    nationality: "",
    birthDate: new Date(),
    idCardNumber: "",
    phoneNumber: "",
    instagramAccount: "",
    bankName: "",
    whatsappAccount: "",
    accountNumber: "",
    linkedInAccount: "",
    height: "",
    weight: "",
    religion: "",
    ethnic: "",
    bloodType: "",
    maritalStatus: "",
    taxType: "",
    npwp: "",
    addressTax: "",
    birthDateFix: "",
    address1: "",
    address2: "",
    address3: "",
    city1: "",
    city2: "",
    city3: "",
    posCode1: "",
    posCode2: "",
    posCode3: "",
    addressPhoneNumber1: "",
    addressPhoneNumber2: "",
    addressPhoneNumber3: "",
    residenceSince1: "",
    residenceSince2: "",
    residenceSince3: "",
    stayedStatus1: "",
    stayedStatus2: "",
    stayedStatus3: "",
    contactName: [""],
    contactShip: [""],
    contactTelephone: [""],
    contactPhone: [""],
    contactStatus: [""],
    contactAddress: [""],
    familyRelationship: ["", ""],
    familyRelationName: ["", ""],
    familyRelationBirth: [new Date(), new Date()],
    familyRelationBirthFix: ["", ""],
    familyRelationEducation: ["", ""],
    familyRelationOccupation: ["", ""],
    familyRelationStatus: ["", ""],
    educationFormalGrade: [""],
    educationFormalInstitution: [""],
    educationFormalMajor: [""],
    educationFormalCity: [""],
    educationFormalStart: [""],
    educationFormalEnd: [""],
    educationFormalGpa: [""],
    educationUnformalType: [""],
    educationUnformalName: [""],
    educationUnformalCity: [""],
    educationUnformalStart: [new Date()],
    educationUnformalStartFix: [""],
    educationUnformalEnd: [new Date()],
    educationUnformalEndFix: [""],
    educationUnformalCertificate: [""],
    workshopTitle: [""],
    workshopName: [""],
    workshopCity: [""],
    workshopStart: [new Date()],
    workshopStartFix: [""],
    workshopEnd: [new Date()],
    workshopEndFix: [""],
    workshopCertificate: [""],
    organizationName: [""],
    organizationPosition: [""],
    organizationCity: [""],
    organizationStart: [new Date()],
    organizationStartFix: [""],
    organizationEnd: [new Date()],
    organizationEndFix: [""],
    languageName: [""],
    languageReading: [""],
    languageWriting: [""],
    languageListening: [""],
    languageSpeaking: [""],
    skillProgram: [""],
    skillApplication: [""],
    skillType: [""],
    skillDescription: [""],
    workExpName: [""],
    workExpAddress: [""],
    workExpBusinessField: [""],
    workExpPosition: [""],
    workExpTelephone: [""],
    workExpStart: [new Date()],
    workExpStartFix: [""],
    workExpEnd: [new Date()],
    workExpEndFix: [""],
    workExpDirectSupervisor: [""],
    workExpSalaryMonth: [""],
    workExpDirectPosition: [""],
    workExpLeavingReason: [""],
    workExpJobDescription: [""],
    jobTypePrefer: "",
    workLocationPrefer: "",
    startWorking: new Date(),
    startWorkingFix: "",
    expectedSalary: "",
    expectedFacility: "",
    personKnow: ["", "", ""],
    strength: [""],
    weakness: [""],
    ilnessStatus: "",
    ilness: ["", ""],
    criminalStatus: "",
    criminal: ["", ""],
    recruitmentStatus: "",
    othersThing: "",
    candidatePhoto: "",
    idCardPhoto: "",
    familyCardPhoto: "",
    certificatePhoto: "",
    taxPhoto: "",
    simPhoto: "",
    maritalCertificatePhoto: "",
    workExpPhoto: "",
    vaccinePhoto: ""
  });

  const handleSubmit = event => {
    event.preventDefault();
    const dateFix = external_moment_default()(signUpData.birthDate).format('YYYY-MM-DD');
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      birthDateFix: dateFix
    }));
    signUpData.familyRelationBirth.map((entry, i) => {
      const temporary = signUpData.familyRelationBirthFix;
      temporary[i] = external_moment_default()(entry).format('YYYY-MM-DD');
      setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
        familyRelationBirthFix: temporary
      }));
    });
    signUpData.educationUnformalStart.map((entry, i) => {
      const temporary = signUpData.educationUnformalStartFix;
      temporary[i] = external_moment_default()(entry).format('YYYY-MM-DD');
      setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
        educationUnformalStartFix: temporary
      }));
    });
    signUpData.educationUnformalEnd.map((entry, i) => {
      const temporary = signUpData.educationUnformalEndFix;
      temporary[i] = external_moment_default()(entry).format('YYYY-MM-DD');
      setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
        educationUnformalEndFix: temporary
      }));
    });
    signUpData.workshopStart.map((entry, i) => {
      const temporary = signUpData.workshopStartFix;
      temporary[i] = external_moment_default()(entry).format('YYYY-MM-DD');
      setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
        workshopStartFix: temporary
      }));
    });
    signUpData.workshopEnd.map((entry, i) => {
      const temporary = signUpData.workshopEndFix;
      temporary[i] = external_moment_default()(entry).format('YYYY-MM-DD');
      setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
        workshopEndFix: temporary
      }));
    });
    signUpData.organizationStart.map((entry, i) => {
      const temporary = signUpData.organizationStartFix;
      temporary[i] = external_moment_default()(entry).format('YYYY-MM-DD');
      setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
        organizationStartFix: temporary
      }));
    });
    signUpData.organizationEnd.map((entry, i) => {
      const temporary = signUpData.organizationEndFix;
      temporary[i] = external_moment_default()(entry).format('YYYY-MM-DD');
      setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
        organizationEndFix: temporary
      }));
    });
    signUpData.workExpStart.map((entry, i) => {
      const temporary = signUpData.workExpStartFix;
      temporary[i] = external_moment_default()(entry).format('YYYY-MM-DD');
      setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
        workExpStartFix: temporary
      }));
    });
    signUpData.workExpEnd.map((entry, i) => {
      const temporary = signUpData.workExpEndFix;
      temporary[i] = external_moment_default()(entry).format('YYYY-MM-DD');
      setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
        workExpStartFix: temporary
      }));
    });
    const dateWorkFix = external_moment_default()(signUpData.startWorking).format('YYYY-MM-DD');
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      startWorkingFix: dateWorkFix
    }));
    console.log(signUpData);
  };

  const cloneContact = () => {
    const contactNameDefault = signUpData.contactName;
    contactNameDefault.push("");
    const contactShipDefault = signUpData.contactShip;
    contactShipDefault.push("");
    const contactTelephoneDefault = signUpData.contactTelephone;
    contactTelephoneDefault.push("");
    const contactPhoneDefault = signUpData.contactPhone;
    contactPhoneDefault.push("");
    const contactStatusDefault = signUpData.contactStatus;
    contactStatusDefault.push("");
    const contactAddressDefault = signUpData.contactAddress;
    contactAddressDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      contactName: contactNameDefault,
      contactShip: contactShipDefault,
      contactTelephone: contactTelephoneDefault,
      contactPhone: contactPhoneDefault,
      contactStatus: contactStatusDefault,
      contactAddress: contactAddressDefault
    }));
  };

  const cloneFamily = () => {
    const familyRelationshipDefault = signUpData.familyRelationship;
    familyRelationshipDefault.push("");
    const familyRelationNameDefault = signUpData.familyRelationName;
    familyRelationNameDefault.push("");
    const familyRelationBirthDefault = signUpData.familyRelationBirth;
    familyRelationBirthDefault.push(new Date());
    const familyRelationBirthFixDefault = signUpData.familyRelationBirthFix;
    familyRelationBirthFixDefault.push("");
    const familyRelationEducationDefault = signUpData.familyRelationEducation;
    familyRelationEducationDefault.push("");
    const familyRelationOccupationDefault = signUpData.familyRelationOccupation;
    familyRelationOccupationDefault.push("");
    const familyRelationStatusDefault = signUpData.familyRelationStatus;
    familyRelationStatusDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      familyRelationship: familyRelationshipDefault,
      familyRelationName: familyRelationNameDefault,
      familyRelationBirth: familyRelationBirthDefault,
      familyRelationBirthFix: familyRelationBirthFixDefault,
      familyRelationEducation: familyRelationEducationDefault,
      familyRelationOccupation: familyRelationOccupationDefault,
      familyRelationStatus: familyRelationStatusDefault
    }));
  };

  const cloneEducationFormal = () => {
    const educationFormalGradeDefault = signUpData.educationFormalGrade;
    educationFormalGradeDefault.push("");
    const educationFormalInstitutionDefault = signUpData.educationFormalInstitution;
    educationFormalInstitutionDefault.push("");
    const educationFormalMajorDefault = signUpData.educationFormalMajor;
    educationFormalMajorDefault.push("");
    const educationFormalCityDefault = signUpData.educationFormalCity;
    educationFormalCityDefault.push("");
    const educationFormalStartDefault = signUpData.educationFormalStart;
    educationFormalStartDefault.push("");
    const educationFormalEndDefault = signUpData.educationFormalEnd;
    educationFormalEndDefault.push("");
    const educationFormalGpaDefault = signUpData.educationFormalGpa;
    educationFormalGpaDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      educationFormalGrade: educationFormalGradeDefault,
      educationFormalInstitution: educationFormalInstitutionDefault,
      educationFormalMajor: educationFormalMajorDefault,
      educationFormalCity: educationFormalCityDefault,
      educationFormalStart: educationFormalStartDefault,
      educationFormalEnd: educationFormalEndDefault,
      educationFormalGpa: educationFormalGpaDefault
    }));
  };

  const cloneEducationUnformal = () => {
    const educationUnformalTypeDefault = signUpData.educationUnformalType;
    educationUnformalTypeDefault.push("");
    const educationUnformalNameDefault = signUpData.educationUnformalName;
    educationUnformalNameDefault.push("");
    const educationUnformalCityDefault = signUpData.educationUnformalCity;
    educationUnformalCityDefault.push("");
    const educationUnformalStartDefault = signUpData.educationUnformalStart;
    educationUnformalStartDefault.push(new Date());
    const educationUnformalStartFixDefault = signUpData.educationUnformalStartFix;
    educationUnformalStartFixDefault.push("");
    const educationUnformalEndDefault = signUpData.educationUnformalEnd;
    educationUnformalEndDefault.push(new Date());
    const educationUnformalEndFixDefault = signUpData.educationUnformalEndFix;
    educationUnformalEndFixDefault.push("");
    const educationUnformalCertificateDefault = signUpData.educationUnformalCertificate;
    educationUnformalCertificateDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      educationUnformalType: educationUnformalTypeDefault,
      educationUnformalName: educationUnformalNameDefault,
      educationUnformalCity: educationUnformalCityDefault,
      educationUnformalStart: educationUnformalStartDefault,
      educationUnformalStartFix: educationUnformalStartFixDefault,
      educationUnformalEnd: educationUnformalEndDefault,
      educationUnformalEndFix: educationUnformalEndFixDefault,
      educationUnformalCertificate: educationUnformalCertificateDefault
    }));
  };

  const cloneWorkshop = () => {
    const workshopTitleDefault = signUpData.workshopTitle;
    workshopTitleDefault.push("");
    const workshopNameDefault = signUpData.workshopName;
    workshopNameDefault.push("");
    const workshopCityDefault = signUpData.workshopCity;
    workshopCityDefault.push("");
    const workshopStartDefault = signUpData.workshopStart;
    workshopStartDefault.push(new Date());
    const workshopStartFixDefault = signUpData.workshopStartFix;
    workshopStartFixDefault.push("");
    const workshopEndDefault = signUpData.workshopEnd;
    workshopEndDefault.push(new Date());
    const workshopEndFixDefault = signUpData.workshopEndFix;
    workshopEndFixDefault.push("");
    const workshopCertificateDefault = signUpData.workshopCertificate;
    workshopCertificateDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      workshopTitle: workshopTitleDefault,
      workshopName: workshopNameDefault,
      workshopCity: workshopCityDefault,
      workshopStart: workshopStartDefault,
      workshopStartFix: workshopStartFixDefault,
      workshopEnd: workshopEndDefault,
      workshopEndFix: workshopEndFixDefault,
      workshopCertificate: workshopCertificateDefault
    }));
  };

  const cloneOrganization = () => {
    const organizationNameDefault = signUpData.organizationName;
    organizationNameDefault.push("");
    const organizationPositionDefault = signUpData.organizationPosition;
    organizationPositionDefault.push("");
    const organizationCityDefault = signUpData.organizationCity;
    organizationCityDefault.push("");
    const organizationStartDefault = signUpData.organizationStart;
    organizationStartDefault.push(new Date());
    const organizationStartFixDefault = signUpData.organizationStartFix;
    organizationStartFixDefault.push("");
    const organizationEndDefault = signUpData.organizationEnd;
    organizationEndDefault.push(new Date());
    const organizationEndFixDefault = signUpData.organizationEndFix;
    organizationEndFixDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      organizationName: organizationNameDefault,
      organizationPosition: organizationPositionDefault,
      organizationCity: organizationCityDefault,
      organizationStart: organizationStartDefault,
      organizationStartFix: organizationStartFixDefault,
      organizationEnd: organizationEndDefault,
      organizationEndFix: organizationEndFixDefault
    }));
  };

  const cloneLanguage = () => {
    const languageNameDefault = signUpData.languageName;
    languageNameDefault.push("");
    const languageReadingDefault = signUpData.languageReading;
    languageReadingDefault.push("");
    const languageWritingDefault = signUpData.languageWriting;
    languageWritingDefault.push("");
    const languageListeningDefault = signUpData.languageListening;
    languageListeningDefault.push("");
    const languageSpeakingDefault = signUpData.languageSpeaking;
    languageSpeakingDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      languageName: languageNameDefault,
      languageReading: languageReadingDefault,
      languageWriting: languageWritingDefault,
      languageListening: languageListeningDefault,
      languageSpeaking: languageSpeakingDefault
    }));
  };

  const cloneComputerSkill = () => {
    const skillProgramDefault = signUpData.skillProgram;
    skillProgramDefault.push("");
    const skillApplicationDefault = signUpData.skillApplication;
    skillApplicationDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      skillProgram: skillProgramDefault,
      skillApplication: skillApplicationDefault
    }));
  };

  const cloneSkill = () => {
    const skillTypeDefault = signUpData.skillType;
    skillTypeDefault.push("");
    const skillDescriptionDefault = signUpData.skillDescription;
    skillDescriptionDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      skillType: skillTypeDefault,
      skillDescription: skillDescriptionDefault
    }));
  };

  const cloneWorkExp = () => {
    const workExpNameDefault = signUpData.workExpName;
    workExpNameDefault.push("");
    const workExpAddressDefault = signUpData.workExpAddress;
    workExpAddressDefault.push("");
    const workExpBusinessFieldDefault = signUpData.workExpBusinessField;
    workExpBusinessFieldDefault.push("");
    const workExpPositionDefault = signUpData.workExpPosition;
    workExpPositionDefault.push("");
    const workExpTelephoneDefault = signUpData.workExpTelephone;
    workExpTelephoneDefault.push("");
    const workExpStartDefault = signUpData.workExpStart;
    workExpStartDefault.push(new Date());
    const workExpStartFixDefault = signUpData.workExpStartFix;
    workExpStartFixDefault.push("");
    const workExpEndDefault = signUpData.workExpEnd;
    workExpEndDefault.push(new Date());
    const workExpEndFixDefault = signUpData.workExpEndFix;
    workExpEndFixDefault.push("");
    const workExpDirectSupervisorDefault = signUpData.workExpDirectSupervisor;
    workExpDirectSupervisorDefault.push("");
    const workExpSalaryMonthDefault = signUpData.workExpSalaryMonth;
    workExpSalaryMonthDefault.push("");
    const workExpDirectPositionDefault = signUpData.workExpDirectPosition;
    workExpDirectPositionDefault.push("");
    const workExpLeavingReasonDefault = signUpData.workExpLeavingReason;
    workExpLeavingReasonDefault.push("");
    const workExpJobDescriptionDefault = signUpData.workExpJobDescription;
    workExpJobDescriptionDefault.push("");
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      workExpName: workExpNameDefault,
      workExpAddress: workExpAddressDefault,
      workExpBusinessField: workExpBusinessFieldDefault,
      workExpPosition: workExpPositionDefault,
      workExpTelephone: workExpTelephoneDefault,
      workExpStart: workExpStartDefault,
      workExpStartFix: workExpStartFixDefault,
      workExpEnd: workExpEndDefault,
      workExpEndFix: workExpEndFixDefault,
      workExpDirectSupervisor: workExpDirectSupervisorDefault,
      workExpSalaryMonth: workExpSalaryMonthDefault,
      workExpDirectPosition: workExpDirectPositionDefault,
      workExpLeavingReason: workExpLeavingReasonDefault,
      workExpJobDescription: workExpJobDescriptionDefault
    }));
  };

  const deleteContact = () => {
    const cloneLengthName = signUpData.contactName.length;
    const afterName = signUpData.contactName.slice(0, cloneLengthName - 1);
    const cloneLengthShip = signUpData.contactShip.length;
    const afterShip = signUpData.contactShip.slice(0, cloneLengthShip - 1);
    const cloneLengthTelephone = signUpData.contactTelephone.length;
    const afterTelephone = signUpData.contactTelephone.slice(0, cloneLengthTelephone - 1);
    const cloneLengthPhone = signUpData.contactPhone.length;
    const afterPhone = signUpData.contactPhone.slice(0, cloneLengthPhone - 1);
    const cloneLengthStatus = signUpData.contactStatus.length;
    const afterStatus = signUpData.contactStatus.slice(0, cloneLengthStatus - 1);
    const cloneLengthAddress = signUpData.contactAddress.length;
    const afterAddress = signUpData.contactAddress.slice(0, cloneLengthAddress - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      contactName: afterName,
      contactShip: afterShip,
      contactTelephone: afterTelephone,
      contactPhone: afterPhone,
      contactStatus: afterStatus,
      contactAddress: afterAddress
    }));
  };

  const deleteFamily = () => {
    const familyLengthRelationship = signUpData.familyRelationship.length;
    const afterRelationship = signUpData.familyRelationship.slice(0, familyLengthRelationship - 1);
    const familyLengthName = signUpData.familyRelationName.length;
    const afterName = signUpData.familyRelationName.slice(0, familyLengthName - 1);
    const familyLengthBirth = signUpData.familyRelationBirth.length;
    const afterBirth = signUpData.familyRelationBirth.slice(0, familyLengthBirth - 1);
    const familyLengthEducation = signUpData.familyRelationEducation.length;
    const afterEducation = signUpData.familyRelationEducation.slice(0, familyLengthEducation - 1);
    const familyLengthOccupation = signUpData.familyRelationOccupation.length;
    const afterOccupation = signUpData.familyRelationOccupation.slice(0, familyLengthOccupation - 1);
    const familyLengthStatus = signUpData.familyRelationStatus.length;
    const afterStatus = signUpData.familyRelationStatus.slice(0, familyLengthStatus - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      familyRelationship: afterRelationship,
      familyRelationName: afterName,
      familyRelationBirth: afterBirth,
      familyRelationEducation: afterEducation,
      familyRelationOccupation: afterOccupation,
      familyRelationStatus: afterStatus
    }));
  };

  const deleteEducationFormal = () => {
    const educationFormalGradeLength = signUpData.educationFormalGrade.length;
    const afterGrade = signUpData.educationFormalGrade.slice(0, educationFormalGradeLength - 1);
    const educationFormalInstitutionLength = signUpData.educationFormalInstitution.length;
    const afterInstitution = signUpData.educationFormalInstitution.slice(0, educationFormalInstitutionLength - 1);
    const educationFormalMajorLength = signUpData.educationFormalMajor.length;
    const afterMajor = signUpData.educationFormalMajor.slice(0, educationFormalMajorLength - 1);
    const educationFormalCity = signUpData.educationFormalCity.length;
    const afterCity = signUpData.educationFormalCity.slice(0, educationFormalCity - 1);
    const educationFormalStartLength = signUpData.educationFormalStart.length;
    const afterStart = signUpData.educationFormalStart.slice(0, educationFormalStartLength - 1);
    const educationFormalEndLength = signUpData.educationFormalEnd.length;
    const afterEnd = signUpData.educationFormalEnd.slice(0, educationFormalEndLength - 1);
    const educationFormalGpaLength = signUpData.educationFormalGpa.length;
    const afterGpa = signUpData.educationFormalGpa.slice(0, educationFormalGpaLength - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      educationFormalGrade: afterGrade,
      educationFormalInstitution: afterInstitution,
      educationFormalMajor: afterMajor,
      educationFormalCity: afterCity,
      educationFormalStart: afterStart,
      educationFormalEnd: afterEnd,
      educationFormalGpa: afterGpa
    }));
  };

  const deleteEducationUnformal = () => {
    const educationUnformalTypeLength = signUpData.educationUnformalType.length;
    const afterType = signUpData.educationUnformalType.slice(0, educationUnformalTypeLength - 1);
    const educationUnformalNameLength = signUpData.educationUnformalName.length;
    const afterName = signUpData.educationUnformalName.slice(0, educationUnformalNameLength - 1);
    const educationUnformalCityLength = signUpData.educationUnformalCity.length;
    const afterCity = signUpData.educationUnformalCity.slice(0, educationUnformalCityLength - 1);
    const educationUnformalStartLength = signUpData.educationUnformalStart.length;
    const afterStart = signUpData.educationUnformalStart.slice(0, educationUnformalStartLength - 1);
    const educationUnformalStartFixLength = signUpData.educationUnformalStartFix.length;
    const afterStartFix = signUpData.educationUnformalStartFix.slice(0, educationUnformalStartFixLength - 1);
    const educationUnformalEndLength = signUpData.educationUnformalEnd.length;
    const afterEnd = signUpData.educationUnformalEnd.slice(0, educationUnformalEndLength - 1);
    const educationUnformalEndFixLength = signUpData.educationUnformalEndFix.length;
    const afterEndFix = signUpData.educationUnformalEndFix.slice(0, educationUnformalEndFixLength - 1);
    const educationUnformalCertificateLength = signUpData.educationUnformalCertificate.length;
    const afterCertificate = signUpData.educationUnformalCertificate.slice(0, educationUnformalCertificateLength - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      educationUnformalType: afterType,
      educationUnformalName: afterName,
      educationUnformalCity: afterCity,
      educationUnformalStart: afterStart,
      educationUnformalStartFix: afterStartFix,
      educationUnformalEnd: afterEnd,
      educationUnformalEndFix: afterEndFix,
      educationUnformalCertificate: afterCertificate
    }));
  };

  const deleteWorkshop = () => {
    const workshopTitleLength = signUpData.workshopTitle.length;
    const afterTitle = signUpData.workshopTitle.slice(0, workshopTitleLength - 1);
    const workshopNameLength = signUpData.workshopName.length;
    const afterName = signUpData.workshopName.slice(0, workshopNameLength - 1);
    const workshopCityLength = signUpData.workshopCity.length;
    const afterCity = signUpData.workshopCity.slice(0, workshopCityLength - 1);
    const workshopStartLength = signUpData.workshopStart.length;
    const afterStart = signUpData.workshopStart.slice(0, workshopStartLength - 1);
    const workshopStartFixLength = signUpData.workshopStartFix.length;
    const afterStartFix = signUpData.workshopStartFix.slice(0, workshopStartFixLength - 1);
    const workshopEndLength = signUpData.workshopEnd.length;
    const afterEnd = signUpData.workshopEnd.slice(0, workshopEndLength - 1);
    const workshopEndFixLength = signUpData.workshopEndFix.length;
    const afterEndFix = signUpData.workshopEndFix.slice(0, workshopEndFixLength - 1);
    const workshopCertificateLength = signUpData.workshopCertificate.length;
    const afterCertificate = signUpData.workshopCertificate.slice(0, workshopCertificateLength - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      workshopTitle: afterTitle,
      workshopName: afterName,
      workshopCity: afterCity,
      workshopStart: afterStart,
      workshopStartFix: afterStartFix,
      workshopEnd: afterEnd,
      workshopEndFix: afterEndFix,
      workshopCertificate: afterCertificate
    }));
  };

  const deleteOrganization = () => {
    const organizationNameLength = signUpData.organizationName.length;
    const afterTitle = signUpData.organizationName.slice(0, organizationNameLength - 1);
    const organizationPositionLength = signUpData.organizationPosition.length;
    const afterName = signUpData.organizationPosition.slice(0, organizationPositionLength - 1);
    const organizationCityLength = signUpData.organizationCity.length;
    const afterCity = signUpData.organizationCity.slice(0, organizationCityLength - 1);
    const organizationStartLength = signUpData.organizationStart.length;
    const afterStart = signUpData.organizationStart.slice(0, organizationStartLength - 1);
    const organizationStartFixLength = signUpData.organizationStartFix.length;
    const afterStartFix = signUpData.organizationStartFix.slice(0, organizationStartFixLength - 1);
    const organizationEndLength = signUpData.organizationEnd.length;
    const afterEnd = signUpData.organizationEnd.slice(0, organizationEndLength - 1);
    const organizationEndFixLength = signUpData.organizationEndFix.length;
    const afterEndFix = signUpData.organizationEndFix.slice(0, organizationEndFixLength - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      organizationName: afterTitle,
      organizationPosition: afterName,
      organizationCity: afterCity,
      organizationStart: afterStart,
      organizationStartFix: afterStartFix,
      organizationEnd: afterEnd,
      organizationEndFix: afterEndFix
    }));
  };

  const deleteLanguage = () => {
    const languageNameLength = signUpData.languageName.length;
    const afterName = signUpData.languageName.slice(0, languageNameLength - 1);
    const languageReadingLength = signUpData.languageReading.length;
    const afterReading = signUpData.languageReading.slice(0, languageReadingLength - 1);
    const languageWritingLength = signUpData.languageWriting.length;
    const afterWriting = signUpData.languageWriting.slice(0, languageWritingLength - 1);
    const languageListeningLength = signUpData.languageListening.length;
    const afterListening = signUpData.languageListening.slice(0, languageListeningLength - 1);
    const languageSpeakingLength = signUpData.languageSpeaking.length;
    const afterSpeaking = signUpData.languageSpeaking.slice(0, languageSpeakingLength - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      languageName: afterName,
      languageReading: afterReading,
      languageWriting: afterWriting,
      languageListening: afterListening,
      languageSpeaking: afterSpeaking
    }));
  };

  const deleteComputerSkill = () => {
    const skillProgramLength = signUpData.skillProgram.length;
    const afterProgram = signUpData.skillProgram.slice(0, skillProgramLength - 1);
    const skillApplicationLength = signUpData.skillApplication.length;
    const afterApplication = signUpData.skillApplication.slice(0, skillApplicationLength - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      skillProgram: afterProgram,
      skillApplication: afterApplication
    }));
  };

  const deleteSkill = () => {
    const skillTypeLength = signUpData.skillType.length;
    const afterType = signUpData.skillType.slice(0, skillTypeLength - 1);
    const skillDescriptionLength = signUpData.skillDescription.length;
    const afterDescription = signUpData.skillDescription.slice(0, skillDescriptionLength - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      skillType: afterType,
      skillDescription: afterDescription
    }));
  };

  const deleteWorkExp = () => {
    const workExpNameLength = signUpData.workExpName.length;
    const afterName = signUpData.workExpName.slice(0, workExpNameLength - 1);
    const workExpAddressLength = signUpData.workExpAddress.length;
    const afterAddress = signUpData.workExpAddress.slice(0, workExpAddressLength - 1);
    const workExpBusinessFieldLength = signUpData.workExpBusinessField.length;
    const afterBusinessField = signUpData.workExpBusinessField.slice(0, workExpBusinessFieldLength - 1);
    const workExpPositionLength = signUpData.workExpPosition.length;
    const afterPosition = signUpData.workExpPosition.slice(0, workExpPositionLength - 1);
    const workExpTelephoneLength = signUpData.workExpTelephone.length;
    const afterTelephone = signUpData.workExpTelephone.slice(0, workExpTelephoneLength - 1);
    const workExpStartLength = signUpData.workExpStart.length;
    const afterStart = signUpData.workExpStart.slice(0, workExpStartLength - 1);
    const workExpStartFixLength = signUpData.workExpStartFix.length;
    const afterStartFix = signUpData.workExpStartFix.slice(0, workExpStartFixLength - 1);
    const workExpEndLength = signUpData.workExpEnd.length;
    const afterEnd = signUpData.workExpEnd.slice(0, workExpEndLength - 1);
    const workExpEndFixLength = signUpData.workExpEndFix.length;
    const afterEndFix = signUpData.workExpEndFix.slice(0, workExpEndFixLength - 1);
    const workExpDirectSupervisorLength = signUpData.workExpDirectSupervisor.length;
    const afterDirectSupervisor = signUpData.workExpDirectSupervisor.slice(0, workExpDirectSupervisorLength - 1);
    const workExpSalaryMonthLength = signUpData.workExpSalaryMonth.length;
    const afterSalaryMonth = signUpData.workExpSalaryMonth.slice(0, workExpSalaryMonthLength - 1);
    const workExpDirectPositionLength = signUpData.workExpDirectPosition.length;
    const afterDirectPosition = signUpData.workExpDirectPosition.slice(0, workExpDirectPositionLength - 1);
    const workExpLeavingReasonLength = signUpData.workExpLeavingReason.length;
    const afterLeavingReason = signUpData.workExpLeavingReason.slice(0, workExpLeavingReasonLength - 1);
    const workExpJobDescriptionLength = signUpData.workExpJobDescription.length;
    const afterJobDescription = signUpData.workExpJobDescription.slice(0, workExpJobDescriptionLength - 1);
    setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
      workExpName: afterName,
      workExpAddress: afterAddress,
      workExpBusinessField: afterBusinessField,
      workExpPosition: afterPosition,
      workExpTelephone: afterTelephone,
      workExpStart: afterStart,
      workExpStartFix: afterStartFix,
      workExpEnd: afterEnd,
      workExpEndFix: afterEndFix,
      workExpDirectSupervisor: afterDirectSupervisor,
      workExpSalaryMonth: afterSalaryMonth,
      workExpDirectPosition: afterDirectPosition,
      workExpLeavingReason: afterLeavingReason,
      workExpJobDescription: afterJobDescription
    }));
  };

  const changeNewContact = (id = 0, stateName = [], type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'contactName':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          contactName: temporary
        }));
        break;

      case 'contactShip':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          contactShip: temporary
        }));
        break;

      case 'contactTelephone':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          contactTelephone: temporary
        }));
        break;

      case 'contactPhone':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          contactPhone: temporary
        }));
        break;

      case 'contactStatus':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          contactStatus: temporary
        }));
        break;

      case 'contactAddress':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          contactAddress: temporary
        }));
        break;
    }
  };

  const changeNewFamily = (id = 0, stateName = [], type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'familyRelationship':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          familyRelationship: temporary
        }));
        break;

      case 'familyRelationName':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          familyRelationName: temporary
        }));
        break;

      case 'familyRelationBirth':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          familyRelationBirth: temporary
        }));
        break;

      case 'familyRelationEducation':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          familyRelationEducation: temporary
        }));
        break;

      case 'familyRelationOccupation':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          familyRelationOccupation: temporary
        }));
        break;

      case 'familyRelationStatus':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          familyRelationStatus: temporary
        }));
        break;
    }
  };

  const changeNewEduFormal = (id = 0, stateName, type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'educationFormalGrade':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationFormalGrade: temporary
        }));
        break;

      case 'educationFormalInstitution':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationFormalInstitution: temporary
        }));
        break;

      case 'educationFormalMajor':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationFormalMajor: temporary
        }));
        break;

      case 'educationFormalCity':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationFormalCity: temporary
        }));
        break;

      case 'educationFormalStart':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationFormalStart: temporary
        }));
        break;

      case 'educationFormalEnd':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationFormalEnd: temporary
        }));
        break;

      case 'educationFormalGpa':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationFormalGpa: temporary
        }));
        break;
    }
  };

  const changeNewEduUnformal = (id = 0, stateName, type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'educationUnformalType':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationUnformalType: temporary
        }));
        break;

      case 'educationUnformalName':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationUnformalName: temporary
        }));
        break;

      case 'educationUnformalCity':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationUnformalCity: temporary
        }));
        break;

      case 'educationUnformalStart':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationUnformalStart: temporary
        }));
        break;

      case 'educationUnformalEnd':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationUnformalEnd: temporary
        }));
        break;

      case 'educationUnformalCertificate':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          educationUnformalCertificate: temporary
        }));
        break;
    }
  };

  const changeNewWorkshop = (id = 0, stateName, type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'workshopTitle':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workshopTitle: temporary
        }));
        break;

      case 'workshopName':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workshopName: temporary
        }));
        break;

      case 'workshopCity':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workshopCity: temporary
        }));
        break;

      case 'workshopStart':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workshopStart: temporary
        }));
        break;

      case 'workshopEnd':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workshopEnd: temporary
        }));
        break;

      case 'workshopCertificate':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workshopCertificate: temporary
        }));
        break;
    }
  };

  const changeNewOrganization = (id = 0, stateName, type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'organizationName':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          organizationName: temporary
        }));
        break;

      case 'organizationPosition':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          organizationPosition: temporary
        }));
        break;

      case 'organizationCity':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          organizationCity: temporary
        }));
        break;

      case 'organizationStart':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          organizationStart: temporary
        }));
        break;

      case 'organizationEnd':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          organizationEnd: temporary
        }));
        break;
    }
  };

  const changeNewLanguage = (id = 0, stateName, type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'languageName':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          languageName: temporary
        }));
        break;

      case 'languageReading':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          languageReading: temporary
        }));
        break;

      case 'languageWriting':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          languageWriting: temporary
        }));
        break;

      case 'languageListening':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          languageListening: temporary
        }));
        break;

      case 'languageSpeaking':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          languageSpeaking: temporary
        }));
        break;
    }
  };

  const changeNewComputerSkill = (id = 0, stateName, type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'skillProgram':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          skillProgram: temporary
        }));
        break;

      case 'skillApplication':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          skillApplication: temporary
        }));
        break;
    }
  };

  const changeNewSkill = (id = 0, stateName, type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'skillType':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          skillType: temporary
        }));
        break;

      case 'skillDescription':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          skillDescription: temporary
        }));
        break;
    }
  };

  const changeNewWorkExp = (id = 0, stateName, type = "", value = "") => {
    const temporary = stateName;
    temporary[id] = value;

    switch (type) {
      case 'workExpName':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpName: temporary
        }));
        break;

      case 'workExpAddress':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpAddress: temporary
        }));
        break;

      case 'workExpBusinessField':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpBusinessField: temporary
        }));
        break;

      case 'workExpPosition':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpPosition: temporary
        }));
        break;

      case 'workExpTelephone':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpTelephone: temporary
        }));
        break;

      case 'workExpStart':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpStart: temporary
        }));
        break;

      case 'workExpStartFix':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpStartFix: temporary
        }));
        break;

      case 'workExpEnd':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpEnd: temporary
        }));
        break;

      case 'workExpEndFix':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpEndFix: temporary
        }));
        break;

      case 'workExpDirectSupervisor':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpDirectSupervisor: temporary
        }));
        break;

      case 'workExpSalaryMonth':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpSalaryMonth: temporary
        }));
        break;

      case 'workExpDirectPosition':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpDirectPosition: temporary
        }));
        break;

      case 'workExpLeavingReason':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpLeavingReason: temporary
        }));
        break;

      case 'workExpJobDescription':
        setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
          workExpJobDescription: temporary
        }));
        break;
    }
  };

  const changePhoto = (type = "", files = {}, element = {}) => {
    const match = ["image/jpeg", "image/png", "image/jpg", "application/pdf"];
    const fileType = files.type;
    let isValid = false;
    match.map(entry => {
      if (entry === fileType) isValid = true;
    });
    const alertElement = document.createElement("span");
    alertElement.classList.add('text-red-500', 'text-sm', 'type-validation');

    if (!isValid) {
      var _document$querySelect;

      (_document$querySelect = document.querySelector('.type-validation')) === null || _document$querySelect === void 0 ? void 0 : _document$querySelect.remove();
      alertElement.innerHTML = 'Tipe file tidak didukung';
      element.parentNode.insertBefore(alertElement, element.nextSibling);
      element.value = '';
      return;
    }

    if (files.size > 2048000) {
      var _document$querySelect2;

      (_document$querySelect2 = document.querySelector('.type-validation')) === null || _document$querySelect2 === void 0 ? void 0 : _document$querySelect2.remove();
      alertElement.innerHTML = 'File melebihi batas maximal (2Mb)';
      element.parentNode.insertBefore(alertElement, element.nextSibling);
      element.value = '';
      return;
    }
    /*const reader = new FileReader()
    reader.readAsDataURL(files)
    reader.onload = () => {
        const response: any = reader.result
        const frameElement = document.querySelector(`#${type}Photo`)
        frameElement?.classList.remove('h-auto', 'w-auto')
        frameElement?.classList.add('h-auto', 'w-auto')
        frameElement?.setAttribute('src', response)
    }*/


    const file = uploadFile(files);
    fetch('https://api.cloudinary.com/v1_1/ayo-belajar-company/image/upload', file).then(res => res.json()).then(res => {
      switch (type) {
        case 'candidate':
          setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
            candidatePhoto: res.secure_url
          }));
          break;

        case 'idCard':
          setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
            idCardPhoto: res.secure_url
          }));
          break;

        case 'familyCard':
          setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
            familyCardPhoto: res.secure_url
          }));
          break;

        case 'certificate':
          setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
            certificatePhoto: res.secure_url
          }));
          break;

        case 'taxType':
          setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
            taxPhoto: res.secure_url
          }));
          break;

        case 'sim':
          setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
            simPhoto: res.secure_url
          }));
          break;

        case 'maritalCertificate':
          setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
            maritalCertificatePhoto: res.secure_url
          }));
          break;

        case 'workExp':
          setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
            workExpPhoto: res.secure_url
          }));
          break;

        case 'vaccine':
          setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
            vaccinePhoto: res.secure_url
          }));
          break;
      }
    }).catch(error => console.error(error));
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mb-2 text-center text-white bg-gradient-to-r from-green-400 to-blue-400 rounded-t-md py-5",
      children: /*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "font-bold text-2xl",
        children: " Form Candidate HRMS "
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mb-2",
      children: /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "block font-semibold p-2 text-sm",
        children: "Formulir lamaran kerja ini akan saya isi dengan sejujur-jujurnya sesuai dengan kenyataan yang sebenarnya. Apabila dikemudian hari terdapat keterangan yang tidak benar, saya bersedia ditindak sesuai dengan ketentuan perusahaan yang berlaku."
      })
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "mb-2 text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
      children: /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "font-bold text-md",
        children: "Jika pilihan isian tidak ada silahkan memilih pilihan Lain-lain / Others."
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
      onSubmit: handleSubmit,
      method: "POST",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "p-4 w-full",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
              children: " Nama Lengkap (Sesuai KTP) "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              name: "officialName",
              value: signUpData.officialName,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                officialName: e.target.value
              })),
              required: true
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
              children: " Nama Panggilan "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.nickName,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                nickName: e.target.value
              }))
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
              children: " Posisi yang dilamar "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.positionApplied,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                positionApplied: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), (dataPositionApplied !== undefined ? dataPositionApplied : []).map((entry, i) => {
                return /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: entry.value,
                  children: entry.label
                }, i);
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
              children: " Sumber Informasi "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.informationSource,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                informationSource: e.target.value
              }))
            })]
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "mb-2 text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: "Data Pribadi"
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "p-4 w-full",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Tempat Lahir "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.birthCity,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                birthCity: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Jakarta "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Bandung "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
              children: " Alamat Email "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.email,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                email: e.target.value
              }))
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Jenis Kelamin "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.gender,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                gender: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Jakarta "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Bandung "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
              children: " Kewarganegaraan "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.nationality,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                nationality: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "219",
                children: " Pria "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "220",
                children: " Wanita "
              })]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Tanggal Lahir "
            }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              dateFormat: "yyyy-MM-dd",
              selected: signUpData.birthDate,
              onChange: date => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                birthDate: external_moment_default()(date, "YYYY-MM-DD").toDate()
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
              children: " No KTP "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.idCardNumber,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                idCardNumber: e.target.value
              }))
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " No Handphone "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.phoneNumber,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                phoneNumber: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
              children: " Media Sosial "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                xmlnsXlink: "http://www.w3.org/1999/xlink",
                className: "h-9 w-9 m-2",
                viewBox: "0 0 512 512",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("radialGradient", {
                  id: "a",
                  cx: "104.957",
                  cy: "447.447",
                  r: "564.646",
                  gradientUnits: "userSpaceOnUse",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0",
                    stopColor: "#fae100"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.054",
                    stopColor: "#fadc04"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.117",
                    stopColor: "#fbce0e"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.183",
                    stopColor: "#fcb720"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.251",
                    stopColor: "#fe9838"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.305",
                    stopColor: "#ff7950"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.492",
                    stopColor: "#ff1c74"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "1",
                    stopColor: "#6c1cd1"
                  })]
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("linearGradient", {
                  id: "b",
                  x1: "196.373",
                  x2: "-671.016",
                  y1: "222.46",
                  y2: "-265.446",
                  gradientUnits: "userSpaceOnUse",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0",
                    stopColor: "#a1b5d8",
                    stopOpacity: "0"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.309",
                    stopColor: "#90a2bd",
                    stopOpacity: "0.31"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.755",
                    stopColor: "#7c8b9c",
                    stopOpacity: "0.757"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "1",
                    stopColor: "#748290"
                  })]
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("linearGradient", {
                  id: "c",
                  x1: "256",
                  x2: "256",
                  y1: "451.966",
                  y2: "531.774",
                  gradientUnits: "userSpaceOnUse",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0",
                    stopColor: "#fae100",
                    stopOpacity: "0"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.307",
                    stopColor: "#fca800",
                    stopOpacity: "0.306"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.627",
                    stopColor: "#fe7300",
                    stopOpacity: "0.627"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.869",
                    stopColor: "#ff5200",
                    stopOpacity: "0.867"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "1",
                    stopColor: "#ff4500"
                  })]
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("linearGradient", {
                  id: "d",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0",
                    stopColor: "#833ab4",
                    stopOpacity: "0"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "1",
                    stopColor: "#833ab4"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("linearGradient", {
                  id: "e",
                  x1: "226.872",
                  x2: "100.161",
                  y1: "226.148",
                  y2: "99.436",
                  gradientUnits: "userSpaceOnUse",
                  xlinkHref: "#d"
                }), /*#__PURE__*/jsx_runtime_.jsx("linearGradient", {
                  id: "f",
                  x1: "350.9",
                  x2: "287.656",
                  y1: "468.287",
                  y2: "170.138",
                  gradientUnits: "userSpaceOnUse",
                  xlinkHref: "#d"
                }), /*#__PURE__*/jsx_runtime_.jsx("linearGradient", {
                  id: "g",
                  x1: "374.965",
                  x2: "120.941",
                  y1: "374.965",
                  y2: "120.941",
                  gradientUnits: "userSpaceOnUse",
                  xlinkHref: "#d"
                }), /*#__PURE__*/jsx_runtime_.jsx("linearGradient", {
                  id: "h",
                  x1: "393.807",
                  x2: "309.806",
                  y1: "221.263",
                  y2: "137.262",
                  gradientUnits: "userSpaceOnUse",
                  xlinkHref: "#d"
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("linearGradient", {
                  id: "i",
                  x1: "357.658",
                  x2: "150.543",
                  y1: "155.05",
                  y2: "362.165",
                  gradientUnits: "userSpaceOnUse",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0",
                    stopColor: "#833ab4"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.092",
                    stopColor: "#9c3495"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.293",
                    stopColor: "#dc2546"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.392",
                    stopColor: "#fd1d1d"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.559",
                    stopColor: "#fc6831"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.689",
                    stopColor: "#fc9b40"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.752",
                    stopColor: "#fcaf45"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.781",
                    stopColor: "#fdb750"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.866",
                    stopColor: "#fecb6a"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "0.942",
                    stopColor: "#ffd87a"
                  }), /*#__PURE__*/jsx_runtime_.jsx("stop", {
                    offset: "1",
                    stopColor: "#ffdc80"
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "url(#a)",
                  d: "M503.234 91.578c-4.66-43.664-39.144-78.156-82.812-82.812-109.508-11.688-219.336-11.688-328.84 0-43.668 4.66-78.156 39.148-82.816 82.812-11.688 109.504-11.688 219.336 0 328.84 4.66 43.668 39.148 78.156 82.812 82.816 109.504 11.688 219.336 11.688 328.844 0 43.668-4.66 78.152-39.148 82.812-82.816 11.688-109.504 11.688-219.332 0-328.84zm0 0"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "url(#b)",
                  d: "M475.387 110.098c-4.133-38.746-34.735-69.352-73.485-73.489-97.172-10.367-194.632-10.367-291.804 0-38.746 4.137-69.352 34.743-73.489 73.489-10.367 97.172-10.367 194.632 0 291.8 4.137 38.75 34.743 69.356 73.489 73.489 97.172 10.37 194.632 10.37 291.8 0 38.75-4.133 69.356-34.739 73.489-73.489 10.37-97.168 10.37-194.628 0-291.8zm0 0"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "url(#c)",
                  d: "M7.672 409.805c.351 3.539.715 7.078 1.094 10.617 4.66 43.664 39.148 78.152 82.816 82.812 109.504 11.688 219.336 11.688 328.84 0 43.668-4.66 78.152-39.148 82.812-82.812.38-3.54.743-7.078 1.098-10.617zm0 0"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "url(#e)",
                  d: "M503.234 420.418a1547.774 1547.774 0 008.711-176.7l-117.03-117.03c-14.622-16.692-35.978-27.11-61.071-28.012-51.606-1.86-103.375-1.766-154.989.008-42.867 1.476-72.843 30.289-80.53 72.636-1.356 7.477-2.169 15.051-3.235 22.582v124.149c.59 4.023 1.457 8.027 1.726 12.074 1.72 25.758 12.305 47.82 29.254 62.746l119.094 119.09c58.445.41 116.895-2.496 175.258-8.727 43.668-4.66 78.152-39.148 82.812-82.816zm0 0"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "url(#f)",
                  d: "M503.234 420.422c-4.656 43.66-39.152 78.156-82.812 82.812a1548.657 1548.657 0 01-175.254 8.727L126.254 393.047c13.785 12.066 31.754 19.414 52.605 20.2 51.602 1.937 103.383 1.886 154.985.026 46.672-1.687 80.445-36.23 81.902-82.902a2373.981 2373.981 0 000-148.793c-.664-21.531-8.223-40.476-20.754-54.812L511.95 243.723c.461 58.918-2.437 117.859-8.715 176.699zm0 0"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "url(#g)",
                  d: "M316.414 200.559c-14.992-16.325-36.504-26.567-60.414-26.567-45.29 0-82.008 36.719-82.008 82.008 0 23.91 10.242 45.422 26.567 60.414l189.738 189.738a1564.245 1564.245 0 0030.121-2.918c43.668-4.66 78.156-39.148 82.816-82.816a1564.245 1564.245 0 002.918-30.121zm0 0"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "url(#h)",
                  d: "M511.008 311.152L358.305 158.453c-3.563-4.676-9.176-7.71-15.508-7.71-10.774 0-19.512 8.734-19.512 19.51 0 6.333 3.035 11.946 7.711 15.509l177.281 177.285a1537.438 1537.438 0 002.73-51.895zm0 0"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "url(#i)",
                  d: "M95.09 193.902c1.066-7.53 1.879-15.105 3.234-22.582 7.684-42.347 37.664-71.16 80.531-72.636 51.614-1.774 103.383-1.868 154.989-.008 46.656 1.68 80.445 36.226 81.902 82.898 1.55 49.559 1.55 99.238 0 148.797-1.457 46.672-35.234 81.215-81.898 82.899-51.606 1.863-103.387 1.91-154.989-.028-46.664-1.754-78.922-36.379-82.043-83.12-.27-4.044-1.136-8.052-1.726-12.075V193.902zM256.043 385.61c23.617 0 47.258.707 70.844-.164 36.98-1.37 59.726-23.441 60.59-60.386a2973.28 2973.28 0 000-138.172c-.864-36.938-23.625-59.524-60.59-60.309a3343.88 3343.88 0 00-140.805 0c-36.684.77-59.496 22.899-60.492 59.43a2579.097 2579.097 0 000 139.933c.996 36.528 23.808 58.145 60.496 59.504 23.289.867 46.637.164 69.957.164zm0 0"
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("g", {
                  fill: "#fff",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
                    d: "M95.09 193.902c1.066-7.53 1.879-15.105 3.234-22.582 7.684-42.347 37.664-71.16 80.531-72.636 51.614-1.774 103.383-1.868 154.989-.008 46.656 1.68 80.445 36.226 81.902 82.898 1.55 49.559 1.55 99.238 0 148.797-1.457 46.672-35.234 81.215-81.898 82.899-51.606 1.863-103.387 1.91-154.989-.028-46.664-1.754-78.922-36.379-82.043-83.12-.27-4.044-1.136-8.052-1.726-12.075V193.902zM256.043 385.61c23.617 0 47.258.707 70.844-.164 36.98-1.37 59.726-23.441 60.59-60.386a2973.28 2973.28 0 000-138.172c-.864-36.938-23.625-59.524-60.59-60.309a3343.88 3343.88 0 00-140.805 0c-36.684.77-59.496 22.899-60.492 59.43a2579.097 2579.097 0 000 139.933c.996 36.528 23.808 58.145 60.496 59.504 23.289.867 46.637.164 69.957.164zm0 0"
                  }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                    d: "M256 173.996c-45.29 0-82.008 36.715-82.008 82.004 0 45.293 36.719 82.008 82.008 82.008 45.293 0 82.008-36.715 82.008-82.008 0-45.29-36.715-82.004-82.008-82.004zm0 135.777c-29.7 0-53.773-24.074-53.773-53.773S226.3 202.227 256 202.227 309.773 226.3 309.773 256 285.7 309.773 256 309.773zm0 0M362.305 170.254c0 10.773-8.735 19.508-19.508 19.508s-19.512-8.735-19.512-19.508c0-10.777 8.738-19.512 19.512-19.512s19.508 8.735 19.508 19.512zm0 0"
                  })]
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.instagramAccount,
                onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  instagramAccount: e.target.value
                }))
              })]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Nama Bank "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.bankName,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                bankName: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "219",
                children: " Pria "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "220",
                children: " Wanita "
              })]
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full md:w-1/2 px-3 mt-6",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                x: "0",
                y: "0",
                className: "h-9 w-9 m-2",
                enableBackground: "new 0 0 512 512",
                version: "1.1",
                viewBox: "0 0 512 512",
                xmlSpace: "preserve",
                children: [/*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "#EDEDED",
                  d: "M0 512l35.31-128C12.359 344.276 0 300.138 0 254.234 0 114.759 114.759 0 255.117 0S512 114.759 512 254.234 395.476 512 255.117 512c-44.138 0-86.51-14.124-124.469-35.31L0 512z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "#55CD6C",
                  d: "M137.71 430.786l7.945 4.414c32.662 20.303 70.621 32.662 110.345 32.662 115.641 0 211.862-96.221 211.862-213.628S371.641 44.138 255.117 44.138 44.138 137.71 44.138 254.234c0 40.607 11.476 80.331 32.662 113.876l5.297 7.945-20.303 74.152 75.916-19.421z"
                }), /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "#FEFEFE",
                  d: "M187.145 135.945l-16.772-.883c-5.297 0-10.593 1.766-14.124 5.297-7.945 7.062-21.186 20.303-24.717 37.959-6.179 26.483 3.531 58.262 26.483 90.041s67.09 82.979 144.772 105.048c24.717 7.062 44.138 2.648 60.028-7.062 12.359-7.945 20.303-20.303 22.952-33.545l2.648-12.359c.883-3.531-.883-7.945-4.414-9.71l-55.614-25.6c-3.531-1.766-7.945-.883-10.593 2.648l-22.069 28.248c-1.766 1.766-4.414 2.648-7.062 1.766-15.007-5.297-65.324-26.483-92.69-79.448-.883-2.648-.883-5.297.883-7.062l21.186-23.834c1.766-2.648 2.648-6.179 1.766-8.828l-25.6-57.379c-.884-2.649-3.532-5.297-7.063-5.297"
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.whatsappAccount,
                onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  whatsappAccount: e.target.value
                }))
              })]
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Nomor Rekening "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.accountNumber,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                accountNumber: e.target.value
              }))
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full md:w-1/2 px-3 mt-6",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex",
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                x: "0",
                y: "0",
                className: "h-9 w-9 m-2",
                enableBackground: "new 0 0 382 382",
                version: "1.1",
                viewBox: "0 0 382 382",
                xmlSpace: "preserve",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  fill: "#0077B7",
                  d: "M347.445 0H34.555C15.471 0 0 15.471 0 34.555v312.889C0 366.529 15.471 382 34.555 382h312.889C366.529 382 382 366.529 382 347.444V34.555C382 15.471 366.529 0 347.445 0zM118.207 329.844c0 5.554-4.502 10.056-10.056 10.056H65.345c-5.554 0-10.056-4.502-10.056-10.056V150.403c0-5.554 4.502-10.056 10.056-10.056h42.806c5.554 0 10.056 4.502 10.056 10.056v179.441zM86.748 123.432c-22.459 0-40.666-18.207-40.666-40.666S64.289 42.1 86.748 42.1s40.666 18.207 40.666 40.666-18.206 40.666-40.666 40.666zM341.91 330.654a9.247 9.247 0 01-9.246 9.246H286.73a9.247 9.247 0 01-9.246-9.246v-84.168c0-12.556 3.683-55.021-32.813-55.021-28.309 0-34.051 29.066-35.204 42.11v97.079a9.246 9.246 0 01-9.246 9.246h-44.426a9.247 9.247 0 01-9.246-9.246V149.593a9.247 9.247 0 019.246-9.246h44.426a9.247 9.247 0 019.246 9.246v15.655c10.497-15.753 26.097-27.912 59.312-27.912 73.552 0 73.131 68.716 73.131 106.472v86.846z"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.linkedInAccount,
                onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  linkedInAccount: e.target.value
                }))
              })]
            })
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Tinggi Badan "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.height,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                height: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Berat Badan "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.weight,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                weight: e.target.value
              }))
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Agama "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.religion,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                religion: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Suku "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.ethnic,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                ethnic: e.target.value
              }))
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Golongan Darah "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.bloodType,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                bloodType: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Status Pernikahan "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.maritalStatus,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                maritalStatus: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Status Pajak "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.taxType,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                taxType: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full md:w-1/2 px-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " NPWP "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.npwp,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                npwp: e.target.value
              }))
            })]
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Alamat Pajak "
            }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.addressTax,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                addressTax: e.target.value
              }))
            })]
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: "Alamat"
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "mx-auto max-w-full flex flex-wrap justify-around box-border pt-2 lg:pt-0 xl:pt-0 2xl:pt-0",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "-mx-3 mb-6 w-full lg:w-1/3 xl:w-1/3 2xl:w-1/3",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "p-4 bg-green-400 text-white text-center",
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "font-bold text-md",
              children: " Alamat Sesuai KTP "
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 py-2 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Alamat KTP "
            }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.address2,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                address2: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Kota "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.city2,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                city2: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Kode Pos "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.posCode2,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                posCode2: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " No Telp/HP "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.addressPhoneNumber2,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                addressPhoneNumber2: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Tinggal Sejak Tahun "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.residenceSince2,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                residenceSince2: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Status Tempat Tinggal "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.stayedStatus2,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                stayedStatus2: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "-mx-3 mb-6 w-full lg:w-1/3 xl:w-1/3 2xl:w-1/3",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "p-4 bg-green-400 text-white text-center",
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "font-bold text-md",
              children: " Alamat Orang Tua "
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 py-2 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
              children: " Alamat Orang Tua "
            }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.address3,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                address3: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Kota "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.city3,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                city3: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Kode Pos "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.posCode3,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                posCode3: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " No Telp/HP "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.addressPhoneNumber3,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                addressPhoneNumber3: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Tinggal Sejak Tahun "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.residenceSince3,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                residenceSince3: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Status Tempat Tinggal "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.stayedStatus3,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                stayedStatus3: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "-mx-3 mb-6 w-full lg:w-1/3 xl:w-1/3 2xl:w-1/3",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "p-4 bg-green-400 text-white text-center",
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "font-bold text-md",
              children: " Alamat Sesuai Domisili "
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 py-2 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Alamat Sekarang "
            }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.address1,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                address1: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Kota "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.city1,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                city1: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Kode Pos "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.posCode1,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                posCode1: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " No Telp/HP "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border-gray-200 border-2 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.addressPhoneNumber1,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                addressPhoneNumber1: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Tinggal Sejak Tahun "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.residenceSince1,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                residenceSince1: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-4 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
              children: " Status Tempat Tinggal "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.stayedStatus1,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                stayedStatus1: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: "Kontak Darurat"
        })
      }), signUpData.contactName.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
                children: " Nama Lengkap "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                name: "officialName",
                value: signUpData.contactName[i],
                onChange: e => changeNewContact(i, signUpData.contactName, 'contactName', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
                children: " Hubungan "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.contactShip[i],
                onChange: e => changeNewContact(i, signUpData.contactShip, 'contactShip', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
                children: " No Telephone "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.contactTelephone[i],
                onChange: e => changeNewContact(i, signUpData.contactTelephone, 'contactTelephone', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
                children: " No Handphone "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.contactPhone[i],
                onChange: e => changeNewContact(i, signUpData.contactPhone, 'contactPhone', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
                children: " Status "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.contactStatus[i],
                onChange: e => changeNewContact(i, signUpData.contactStatus, 'contactStatus', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold font-bold mb-2",
                children: " Alamat "
              }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.contactAddress[i],
                onChange: e => changeNewContact(i, signUpData.contactAddress, 'contactAddress', e.target.value)
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneContact,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.contactName.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteContact,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Keluarga "
        })
      }), signUpData.familyRelationship.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Hubungan "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.familyRelationship[i],
                onChange: e => changeNewFamily(i, signUpData.familyRelationship, 'familyRelationship', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Nama Lengkap "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.familyRelationName[i],
                onChange: e => changeNewFamily(i, signUpData.familyRelationName, 'familyRelationName', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Tanggal Lahir "
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                dateFormat: "yyyy-MM-dd",
                selected: signUpData.familyRelationBirth[i],
                onChange: date => changeNewFamily(i, signUpData.familyRelationBirth, 'familyRelationBirth', external_moment_default()(date, "YYYY-MM-DD").toDate())
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Pendidikan Terakhir "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.familyRelationEducation[i],
                onChange: e => changeNewFamily(i, signUpData.familyRelationEducation, 'familyRelationEducation', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Pekerjaan "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.familyRelationOccupation[i],
                onChange: e => changeNewFamily(i, signUpData.familyRelationOccupation, 'familyRelationOccupation', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Status "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.familyRelationStatus[i],
                onChange: e => changeNewFamily(i, signUpData.familyRelationStatus, 'familyRelationStatus', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneFamily,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.familyRelationship.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteFamily,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Pendidikan Formal "
        })
      }), signUpData.educationFormalGrade.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Tingkat "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationFormalGrade[i],
                onChange: e => changeNewEduFormal(i, signUpData.educationFormalGrade, 'educationFormalGrade', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Nama Lembaga "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationFormalInstitution[i],
                onChange: e => changeNewEduFormal(i, signUpData.educationFormalInstitution, 'educationFormalInstitution', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Jurusan "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none hidden w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationFormalMajor[i],
                onChange: e => changeNewEduFormal(i, signUpData.educationFormalMajor, 'educationFormalMajor', e.target.value),
                id: "majorSelect",
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Kota "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationFormalCity[i],
                onChange: e => changeNewEduFormal(i, signUpData.educationFormalCity, 'educationFormalCity', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Mulai "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationFormalStart[i],
                onChange: e => changeNewEduFormal(i, signUpData.educationFormalStart, 'educationFormalStart', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Selesai "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationFormalEnd[i],
                onChange: e => changeNewEduFormal(i, signUpData.educationFormalEnd, 'educationFormalEnd', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/6 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Nilai "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationFormalGpa[i],
                onChange: e => changeNewEduFormal(i, signUpData.educationFormalGpa, 'educationFormalGpa', e.target.value)
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneEducationFormal,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.educationFormalGrade.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteEducationFormal,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Pendidikan Non Formal "
        })
      }), signUpData.educationUnformalType.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Jenis Kursus "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationUnformalType[i],
                onChange: e => changeNewEduUnformal(i, signUpData.educationUnformalType, 'educationUnformalType', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Nama Lembaga "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationUnformalName[i],
                onChange: e => changeNewEduUnformal(i, signUpData.educationUnformalName, 'educationUnformalName', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Kota "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationUnformalCity[i],
                onChange: e => changeNewEduUnformal(i, signUpData.educationUnformalCity, 'educationUnformalCity', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Periode "
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                dateFormat: "yyyy-MM-dd",
                selected: signUpData.educationUnformalStart[i],
                onChange: date => changeNewEduUnformal(i, signUpData.educationUnformalStart, 'educationUnformalStart', external_moment_default()(date, "YYYY-MM-DD").toDate())
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                dateFormat: "yyyy-MM-dd",
                selected: signUpData.educationUnformalStart[i],
                onChange: date => changeNewEduUnformal(i, signUpData.educationUnformalEnd, 'educationUnformalEnd', external_moment_default()(date, "YYYY-MM-DD").toDate())
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Berijazah "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.educationUnformalCertificate[i],
                onChange: e => changeNewEduUnformal(i, signUpData.educationUnformalCertificate, 'educationUnformalCertificate', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneEducationUnformal,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.educationUnformalType.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteEducationUnformal,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Penataran dan lokakarya "
        })
      }), signUpData.workshopTitle.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Jenis Kursus "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workshopTitle[i],
                onChange: e => changeNewWorkshop(i, signUpData.workshopTitle, 'workshopTitle', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Nama Lembaga "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workshopName[i],
                onChange: e => changeNewWorkshop(i, signUpData.workshopName, 'workshopName', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Kota "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workshopCity[i],
                onChange: e => changeNewWorkshop(i, signUpData.workshopCity, 'workshopCity', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Periode "
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                dateFormat: "yyyy-MM-dd",
                selected: signUpData.workshopStart[i],
                onChange: date => changeNewWorkshop(i, signUpData.workshopStart, 'workshopStart', external_moment_default()(date, "YYYY-MM-DD").toDate())
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                dateFormat: "yyyy-MM-dd",
                selected: signUpData.workshopEnd[i],
                onChange: date => changeNewWorkshop(i, signUpData.workshopEnd, 'workshopEnd', external_moment_default()(date, "YYYY-MM-DD").toDate())
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Berijazah "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                onChange: e => changeNewWorkshop(i, signUpData.workshopCertificate, 'workshopCertificate', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneWorkshop,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.workshopTitle.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteWorkshop,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Pengalaman Organisasi "
        })
      }), signUpData.organizationName.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/4 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Nama Organisasi "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.organizationName[i],
                onChange: e => changeNewOrganization(i, signUpData.organizationName, 'organizationName', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/4 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Posisi "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.organizationPosition[i],
                onChange: e => changeNewOrganization(i, signUpData.organizationPosition, 'organizationPosition', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/4 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Kota "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.organizationCity[i],
                onChange: e => changeNewOrganization(i, signUpData.organizationCity, 'organizationCity', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/4 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Periode "
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                dateFormat: "yyyy-MM-dd",
                selected: signUpData.organizationStart[i],
                onChange: date => changeNewOrganization(i, signUpData.organizationStart, 'organizationStart', external_moment_default()(date, "YYYY-MM-DD").toDate())
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                dateFormat: "yyyy-MM-dd",
                selected: signUpData.organizationEnd[i],
                onChange: date => changeNewOrganization(i, signUpData.organizationEnd, 'organizationEnd', external_moment_default()(date, "YYYY-MM-DD").toDate())
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneOrganization,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.organizationName.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteOrganization,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Kemampuan Bahasa "
        })
      }), signUpData.languageName.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Bahasa "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.languageName[i],
                onChange: e => changeNewLanguage(i, signUpData.languageName, 'languageName', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Membaca "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.languageReading[i],
                onChange: e => changeNewLanguage(i, signUpData.languageReading, 'languageReading', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Menulis "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.languageWriting[i],
                onChange: e => changeNewLanguage(i, signUpData.languageWriting, 'languageWriting', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Mendengarkan "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.languageListening[i],
                onChange: e => changeNewLanguage(i, signUpData.languageListening, 'languageListening', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/5 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Berbicara "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.languageSpeaking[i],
                onChange: e => changeNewLanguage(i, signUpData.languageSpeaking, 'languageSpeaking', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneLanguage,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.languageName.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteLanguage,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Keterampilan Komputer "
        })
      }), signUpData.skillProgram.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Jenis Program "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.skillProgram[i],
                onChange: e => changeNewComputerSkill(i, signUpData.skillProgram, 'skillProgram', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Aplikasi "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.skillApplication[i],
                onChange: e => changeNewComputerSkill(i, signUpData.skillApplication, 'skillApplication', e.target.value)
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneComputerSkill,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.skillProgram.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteComputerSkill,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Keterampilan Lain "
        })
      }), signUpData.skillType.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Jenis "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.skillType[i],
                onChange: e => changeNewSkill(i, signUpData.skillType, 'skillType', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Deskripsi "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.skillDescription[i],
                onChange: e => changeNewSkill(i, signUpData.skillDescription, 'skillDescription', e.target.value)
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneSkill,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.skillProgram.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteSkill,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Pengalaman Kerja "
        })
      }), signUpData.workExpName.map((entry, i) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "p-4 w-full border-b-2 border-gray-300",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex flex-wrap -mx-3 mb-6",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Nama Perusahaan "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpName[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpName, 'workExpName', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Alamat Perusahaan "
              }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpAddress[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpAddress, 'workExpAddress', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Bidang Usaha "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpBusinessField[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpBusinessField, 'workExpBusinessField', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Jabatan "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpPosition[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpPosition, 'workExpPosition', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0 lg:mt-5",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " No. Telephone "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpTelephone[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpTelephone, 'workExpTelephone', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Periode Kerja "
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                dateFormat: "yyyy-MM-dd",
                selected: signUpData.workExpStart[i],
                onChange: date => changeNewWorkExp(i, signUpData.workExpStart, 'workExpStart', external_moment_default()(date, "YYYY-MM-DD").toDate())
              }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                dateFormat: "yyyy-MM-dd",
                selected: signUpData.workExpEnd[i],
                onChange: date => changeNewWorkExp(i, signUpData.workExpEnd, 'workExpEnd', external_moment_default()(date, "YYYY-MM-DD").toDate())
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Nama Atasan Langsung "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpDirectSupervisor[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpDirectSupervisor, 'workExpDirectSupervisor', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Jabatan Atasan Langsung "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpDirectPosition[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpDirectPosition, 'workExpDirectPosition', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Pendapatan /Bulan "
              }), /*#__PURE__*/jsx_runtime_.jsx("input", {
                type: "text",
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpSalaryMonth[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpSalaryMonth, 'workExpSalaryMonth', e.target.value)
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full lg:w-1/2 px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Alasan Berhenti "
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
                className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpLeavingReason[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpLeavingReason, 'workExpLeavingReason', e.target.value),
                children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "",
                  children: "- choose -"
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "1",
                  children: " Islam "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "2",
                  children: " Kristen "
                }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                  value: "3",
                  children: " Katolik "
                })]
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "w-full px-3 mb-6 md:mb-0",
              children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
                className: "block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2",
                children: " Uraian Tugas "
              }), /*#__PURE__*/jsx_runtime_.jsx("textarea", {
                className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                value: signUpData.workExpJobDescription[i],
                onChange: e => changeNewWorkExp(i, signUpData.workExpJobDescription, 'workExpJobDescription', e.target.value)
              })]
            })]
          })
        }, i);
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3 mb-6 md:mb-2",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-blue-500 text-white border-2 border-blue-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-blue-700 appearance-none block leading-tight`,
              onClick: cloneWorkExp,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M12 6v6m0 0v6m0-6h6m-6 0H6"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Tambah Lagi"
              })]
            })
          }), signUpData.workExpName.length > 1 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full lg:w-44 md:1/2 px-3",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
              className: `py-2 px-4 w-full bg-white text-red-500 border-2 border-red-500 text-sm rounded shadow-md transition duration-200 flex hover:bg-red-500 hover:text-white appearance-none block leading-tight`,
              onClick: deleteWorkExp,
              children: [/*#__PURE__*/jsx_runtime_.jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                className: "h-6 w-6",
                fill: "none",
                viewBox: "0 0 24 24",
                stroke: "currentColor",
                children: /*#__PURE__*/jsx_runtime_.jsx("path", {
                  strokeLinecap: "round",
                  strokeLinejoin: "round",
                  strokeWidth: 2,
                  d: "M6 18L18 6M6 6l12 12"
                })
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "ml-3 mt-1",
                children: "Delete row"
              })]
            })
          }) : null]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Lain - Lain "
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " Jenis pekerjaan yang anda sukai "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.jobTypePrefer,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                jobTypePrefer: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " Jenis lokasi kerja yang anda sukai "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.workLocationPrefer,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                workLocationPrefer: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " Bila diterima, kapan anda dapat mulai bekerja? "
            }), /*#__PURE__*/jsx_runtime_.jsx((external_react_datepicker_default()), {
              className: `appearance-none block text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              dateFormat: "yyyy-MM-dd",
              selected: signUpData.birthDate,
              onChange: date => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                birthDate: external_moment_default()(date, "YYYY-MM-DD").toDate()
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " Besar gaji yang diharapkan "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.expectedSalary,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                expectedSalary: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " Fasilitas yang diharapkan "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.expectedFacility,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                expectedFacility: e.target.value
              }))
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " Orang-orang yang anda kenal dalam perusahaan ini? "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.personKnow[0],
              onChange: e => {
                const temporary = signUpData.personKnow;
                temporary[0] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  personKnow: temporary
                }));
              }
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.personKnow[1],
              onChange: e => {
                const temporary = signUpData.personKnow;
                temporary[1] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  personKnow: temporary
                }));
              }
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.personKnow[2],
              onChange: e => {
                const temporary = signUpData.personKnow;
                temporary[2] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  personKnow: temporary
                }));
              }
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " 3 (tiga) kelebihan yang anda miliki "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.strength[0],
              onChange: e => {
                const temporary = signUpData.strength;
                temporary[0] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  strength: temporary
                }));
              }
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.strength[1],
              onChange: e => {
                const temporary = signUpData.strength;
                temporary[1] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  strength: temporary
                }));
              }
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.strength[2],
              onChange: e => {
                const temporary = signUpData.strength;
                temporary[2] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  strength: temporary
                }));
              }
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " 3 (tiga) kelemahan yang anda miliki "
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.weakness[0],
              onChange: e => {
                const temporary = signUpData.weakness;
                temporary[0] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  weakness: temporary
                }));
              }
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.weakness[1],
              onChange: e => {
                const temporary = signUpData.weakness;
                temporary[1] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  weakness: temporary
                }));
              }
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.weakness[2],
              onChange: e => {
                const temporary = signUpData.weakness;
                temporary[2] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  weakness: temporary
                }));
              }
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " Penyakit berat yang pernah diderita & kapan? "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full lg:w-1/4 text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.ilnessStatus,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                ilnessStatus: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.ilness[0],
              onChange: e => {
                const temporary = signUpData.ilness;
                temporary[0] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  ilness: temporary
                }));
              }
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.ilness[1],
              onChange: e => {
                const temporary = signUpData.ilness;
                temporary[1] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  ilness: temporary
                }));
              }
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "block uppercase tracking-wide text-gray-700 font-bold mb-2 text-xs",
              children: " Keterlibatan perkara pidana, masalah apa & kapan? "
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("select", {
              className: `appearance-none block w-full lg:w-1/4 text-gray-700 border-2 border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.criminalStatus,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                criminalStatus: e.target.value
              })),
              children: [/*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "",
                children: "- choose -"
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "1",
                children: " Islam "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "2",
                children: " Kristen "
              }), /*#__PURE__*/jsx_runtime_.jsx("option", {
                value: "3",
                children: " Katolik "
              })]
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.criminal[0],
              onChange: e => {
                const temporary = signUpData.criminal;
                temporary[0] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  criminal: temporary
                }));
              }
            }), /*#__PURE__*/jsx_runtime_.jsx("input", {
              type: "text",
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.criminal[1],
              onChange: e => {
                const temporary = signUpData.criminal;
                temporary[1] = e.target.value;
                setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                  criminal: temporary
                }));
              }
            })]
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Bila anda sedang dalam proses seleksi di perusahaan lain, sebutkan nama perusahaan tersebut, posisi yang anda lamar dan seberapa jauh proses tersebut? "
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: /*#__PURE__*/jsx_runtime_.jsx("textarea", {
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.recruitmentStatus,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                recruitmentStatus: e.target.value
              }))
            })
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Tuliskan keterangan lain yang ingin yang anda sampaikan dan perlu untuk diketahui "
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex flex-wrap -mx-3 mb-6",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full px-3 mb-6 md:mb-0",
            children: /*#__PURE__*/jsx_runtime_.jsx("textarea", {
              className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
              value: signUpData.othersThing,
              onChange: e => setSignUpData(_objectSpread(_objectSpread({}, signUpData), {}, {
                othersThing: e.target.value
              }))
            })
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center text-white bg-gradient-to-r from-green-400 to-blue-400 py-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "font-bold text-md",
          children: " Kelengkapan Data Diri "
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "p-4 w-full",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "border-b border-gray-200 shadow overflow-x-auto",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("table", {
            className: "mx-auto w-full whitescape-nowrap rounded-lg bg-white divide-y divide-gray-300 overflow-hidden",
            children: [/*#__PURE__*/jsx_runtime_.jsx("thead", {
              className: "bg-gray-50",
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "text-left",
                children: [/*#__PURE__*/jsx_runtime_.jsx("th", {
                  className: "font-semibold text-sm uppercase px-6 py-4 lg:w-3/6",
                  children: "Jenis"
                }), /*#__PURE__*/jsx_runtime_.jsx("th", {
                  className: "font-semibold text-sm uppercase px-6 py-4 lg:w-2/6",
                  children: "Upload"
                }), /*#__PURE__*/jsx_runtime_.jsx("th", {
                  className: "font-semibold text-sm uppercase px-6 py-4 lg:w-1/6",
                  children: "Hasil"
                })]
              })
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("tbody", {
              className: "bg-white divide-y divide-gray-300",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "whitespace-nowrap",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-md font-bold",
                    children: " Foto diri kandidat "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Max Size: 2048Kb "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Allowed file type: PNG, jpg "
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "file",
                    className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                    onChange: e => changePhoto('candidate', !e.target.files ? null : e.target.files[0], e.target)
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "lg:px-6 lg:py-4",
                  children: signUpData.candidatePhoto !== '' ? /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: signUpData.candidatePhoto,
                    alt: 'Preview image',
                    id: "candidatePhoto",
                    height: 500,
                    width: 500
                  }) : null
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "whitespace-nowrap",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-md font-bold",
                    children: " Foto KTP "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Max Size: 2048Kb "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Allowed file type: PNG, jpg "
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "file",
                    className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                    onChange: e => changePhoto('idCard', !e.target.files ? null : e.target.files[0], e.target)
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "lg:px-6 lg:py-4",
                  children: signUpData.idCardPhoto !== '' ? /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: signUpData.idCardPhoto,
                    alt: 'Preview image',
                    id: "candidatePhoto",
                    height: 500,
                    width: 500
                  }) : null
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "whitespace-nowrap",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-md font-bold",
                    children: " Foto Kartu Keluarga "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Max Size: 2048Kb "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Allowed file type: PNG, jpg "
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "file",
                    className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                    onChange: e => changePhoto('familyCard', !e.target.files ? null : e.target.files[0], e.target)
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "lg:px-6 lg:py-4",
                  children: signUpData.familyCardPhoto !== '' ? /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: signUpData.familyCardPhoto,
                    alt: 'Preview image',
                    id: "candidatePhoto",
                    height: 500,
                    width: 500
                  }) : null
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "whitespace-nowrap",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-md font-bold",
                    children: " Foto Sertifikat "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Max Size: 2048Kb "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Allowed file type: PNG, jpg "
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "file",
                    className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                    onChange: e => changePhoto('certificate', !e.target.files ? null : e.target.files[0], e.target)
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "lg:px-6 lg:py-4 text-gray-900",
                  children: signUpData.certificatePhoto !== '' ? /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: signUpData.certificatePhoto,
                    alt: 'Preview image',
                    id: "candidatePhoto",
                    height: 500,
                    width: 500
                  }) : null
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "whitespace-nowrap",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-md font-bold",
                    children: " Foto NPWP "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Max Size: 2048Kb "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Allowed file type: PNG, jpg "
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "file",
                    className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                    onChange: e => changePhoto('tax', !e.target.files ? null : e.target.files[0], e.target)
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "lg:px-6 lg:py-4 text-gray-900",
                  children: signUpData.taxPhoto !== '' ? /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: signUpData.taxPhoto,
                    alt: 'Preview image',
                    id: "candidatePhoto",
                    height: 500,
                    width: 500
                  }) : null
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "whitespace-nowrap",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-md font-bold",
                    children: " Foto SIM "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Max Size: 2048Kb "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Allowed file type: PNG, jpg "
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "file",
                    className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                    onChange: e => changePhoto('sim', !e.target.files ? null : e.target.files[0], e.target)
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "lg:px-6 lg:py-4 text-gray-900",
                  children: signUpData.simPhoto !== '' ? /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: signUpData.simPhoto,
                    alt: 'Preview image',
                    id: "candidatePhoto",
                    height: 500,
                    width: 500
                  }) : null
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "whitespace-nowrap",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-md font-bold",
                    children: " Foto Akte Nikah "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Max Size: 2048Kb "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Allowed file type: PNG, jpg "
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "file",
                    className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                    onChange: e => changePhoto('maritalCertificate', !e.target.files ? null : e.target.files[0], e.target)
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "lg:px-6 lg:py-4 text-gray-900",
                  children: signUpData.maritalCertificatePhoto !== '' ? /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: signUpData.maritalCertificatePhoto,
                    alt: 'Preview image',
                    id: "candidatePhoto",
                    height: 500,
                    width: 500
                  }) : null
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "whitespace-nowrap",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-md font-bold",
                    children: " Foto Surat Pengalaman Kerja "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Max Size: 2048Kb "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Allowed file type: PNG, jpg "
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "file",
                    className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                    onChange: e => changePhoto('workExp', !e.target.files ? null : e.target.files[0], e.target)
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "lg:px-6 lg:py-4 text-gray-900",
                  children: signUpData.workExpPhoto !== '' ? /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: signUpData.workExpPhoto,
                    alt: 'Preview image',
                    id: "candidatePhoto",
                    height: 500,
                    width: 500
                  }) : null
                })]
              }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("tr", {
                className: "whitespace-nowrap",
                children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-md font-bold",
                    children: " Foto Sertifikat Vaksin "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Max Size: 2048Kb "
                  }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                    className: "text-sm",
                    children: " ***Allowed file type: PNG, jpg "
                  })]
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "px-6 py-4 text-gray-900",
                  children: /*#__PURE__*/jsx_runtime_.jsx("input", {
                    type: "file",
                    className: `appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-purple-700`,
                    onChange: e => changePhoto('vaccine', !e.target.files ? null : e.target.files[0], e.target)
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("td", {
                  className: "lg:px-6 lg:py-4 text-gray-900",
                  children: signUpData.vaccinePhoto !== '' ? /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: signUpData.vaccinePhoto,
                    alt: 'Preview image',
                    id: "candidatePhoto",
                    height: 500,
                    width: 500
                  }) : null
                })]
              })]
            })]
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "flex flex-wrap justify-end mx-3 mb-6 pb-3",
        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "px-6 py-2 m-3 bg-gradient-to-r from-green-400 to-blue-400 hover:from-green-500 hover:to-blue-500 text-white rounded shadow-md transition duration-200",
          type: "submit",
          children: "Simpan"
        })
      })]
    })]
  });
};

/* harmony default export */ const components_Candidate = (Candidate);
// EXTERNAL MODULE: ./pages/api/combobox.ts + 2 modules
var combobox = __webpack_require__(117);
;// CONCATENATED MODULE: ./pages/candidateform.tsx









const CandidateForm = ({
  positionApplied
}) => {
  const {
    setPositionApplied
  } = useStoreOption();
  (0,external_react_.useEffect)(() => {
    setPositionApplied(positionApplied);
  }, [positionApplied]);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
      children: [/*#__PURE__*/jsx_runtime_.jsx("title", {
        children: "Form Candidate HRMS"
      }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
        name: "description",
        content: "Generated by create next app"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "p-10 min-h-screen bg-gray-200",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "bg-white shadow-md rounded-md",
        children: /*#__PURE__*/jsx_runtime_.jsx(components_Candidate, {})
      })
    })]
  });
};

const getStaticProps = async () => {
  const res = await (0,combobox.default)("genre", 0);
  const positionApplied = [];
  res.map(key => {
    positionApplied.push({
      value: key.combo_key,
      label: key.combo_name
    });
  });
  return {
    props: {
      positionApplied
    }
  };
};
/* harmony default export */ const candidateform = (CandidateForm);

/***/ }),

/***/ 994:
/***/ (() => {



/***/ }),

/***/ 376:
/***/ ((module) => {

"use strict";
module.exports = require("axios");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [675,117], () => (__webpack_exec__(756)));
module.exports = __webpack_exports__;

})();