"use strict";
exports.id = 117;
exports.ids = [117];
exports.modules = {

/***/ 117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ getCombo)
});

// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(376);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
;// CONCATENATED MODULE: ./lib/http.ts

const RES = {
  data: new Object()
};

const http = function (url = null) {
  this.base = url;

  this.combineurl = url => {
    if (this.base === null) {
      return url;
    } else {
      return `${this.base}${url}`;
    }
  };

  this.wreturn = (res = RES) => {
    return res.data;
  };
};

http.prototype.get = async function (url) {
  const newurl = this.combineurl(url);
  const res = await external_axios_default().get(newurl);
  return this.wreturn(res);
};

http.prototype.post = async function (url, param) {
  const newurl = this.combineurl(url);
  const res = await external_axios_default().post(newurl, param);
  return this.wreturn(res);
};

http.prototype.put = async function (url, param) {
  const newurl = this.combineurl(url);
  const res = await external_axios_default().put(newurl, param);
  return this.wreturn(res);
};

http.prototype.delete = async function (url, param) {
  const newurl = this.combineurl(url);
  const res = await external_axios_default()({
    method: 'DELETE',
    url: newurl,
    data: param
  });
  return this.wreturn(res);
};

/* harmony default export */ const lib_http = (http);
;// CONCATENATED MODULE: ./lib.ts


;// CONCATENATED MODULE: ./pages/api/combobox.ts

const combobox_http = new lib_http('http://127.0.0.1:70/api');
async function getCombo(type, id) {
  const obj = {
    type: type,
    parent: id,
    isarray: true
  };
  const res = await combobox_http.post('/getCombo', obj);
  return res.result;
}

/***/ })

};
;